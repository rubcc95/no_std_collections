use core::mem::MaybeUninit as MaybeUninitItem;

pub struct MaybeUninit<T, const N: usize> {
    array: [T; N],
}

impl<T, const N: usize> MaybeUninit<T, N> {
    const ITEM: T = unsafe { MaybeUninitItem::uninit().assume_init() };
    const DEFAULT: MaybeUninit<T, N> = Self {
        array: [Self::ITEM; N],
    };

    #[inline(always)]
    pub const fn uninit() -> Self {
        Self::DEFAULT
    }

    #[inline(always)]
    pub const fn new(array: [T; N]) -> Self {
        Self{
            array,
        }
    }

    #[inline(always)]
    pub unsafe fn assume_init(self) -> [T; N] {
        self.array
    }

    #[inline(always)]
    pub const unsafe fn assume_init_ref(&self) -> &[T; N] {
        &self.array
    }

    #[inline(always)]
    pub unsafe fn assume_init_mut(&mut self) -> &mut [T; N] {
        &mut self.array
    }

    #[inline(always)]
    pub fn get(&self, index: usize) -> Option<&MaybeUninitItem<T>> {
        unsafe { core::mem::transmute(self.array.get(index)) }
    }

    #[inline]
    pub fn get_mut(&mut self, index: usize) -> Option<&mut MaybeUninitItem<T>> {
        unsafe { core::mem::transmute(self.array.get_mut(index)) }
    }

    #[inline]
    pub unsafe fn get_unchecked(&self, index: usize) -> &MaybeUninitItem<T> {
        core::mem::transmute(self.array.get_unchecked(index))
    }

    #[inline]
    pub unsafe fn get_unchecked_mut(&mut self, index: usize) -> &mut MaybeUninitItem<T> {
        core::mem::transmute(self.array.get_unchecked_mut(index))
    }
}

impl<T, const N: usize> Default for MaybeUninit<T,N>{
    #[inline(always)]
    fn default() -> Self {
        Self::uninit()
    }    
}

impl<T, const N: usize> From<[T; N]> for MaybeUninit<T, N>{
    #[inline(always)]
    fn from(value: [T; N]) -> Self {
        Self::new(value)
    }
}