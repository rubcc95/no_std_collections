use core::mem::MaybeUninit;
use core::ops::{Range, RangeBounds};
use core::ptr;
use core::slice;

use crate::{array, traits::*};

pub struct StackVec<T, const N: usize> {
    len: usize,
    buff: array::MaybeUninit<T, N>,
}

impl<T, const N: usize> StackVec<T, N> {
    #[inline(always)]
    fn len(&self) -> usize {
        self.len
    }

    #[inline]
    pub fn as_slice(&self) -> &[T] {
        unsafe { slice::from_raw_parts(self.buff.assume_init_ref().as_ptr() as *const T, self.len) }
    }

    #[inline]
    pub fn as_mut_slice(&mut self) -> &mut [T] {
        unsafe {
            slice::from_raw_parts_mut(self.buff.assume_init_mut().as_mut_ptr() as *mut T, self.len)
        }
    }

    pub unsafe fn push_unchecked(&mut self, value: T) {
        ptr::write(
            self.buff.assume_init_mut().as_mut_ptr().add(self.len) as *mut T,
            value,
        );
        self.len += 1;
    }

    pub unsafe fn append_unchecked<V: SliceOwner<Item = T>>(&mut self, other: V) {
        ptr::copy_nonoverlapping(other.as_ptr(), self.as_mut_ptr().add(self.len), other.len());
        self.len += other.len();
    }

    pub fn map<K, F: FnMut(T) -> K>(self, mut f: F) -> StackVec<K, N> {
        let mut uninit = array::MaybeUninit::uninit();
        for idx in 0..self.len {
            unsafe {
                *uninit.get_unchecked_mut(idx) =
                    MaybeUninit::new(f(ptr::read(self.buff.assume_init_ref().get_unchecked(idx))))
            };
        }
        StackVec {
            len: self.len,
            buff: uninit,
        }
    }

    
    pub fn map_ref<'a, K, F: FnMut(&'a T) -> K>(&'a self, mut f: F) -> StackVec<K, N> {
        let mut uninit = array::MaybeUninit::uninit();
        for idx in 0..self.len {
            unsafe {
                *uninit.get_unchecked_mut(idx) =
                    MaybeUninit::new(f(self.buff.assume_init_ref().get_unchecked(idx)))
            };
        }
        StackVec {
            len: self.len,
            buff: uninit,
        }
    }

    pub unsafe fn insert_unchecked(&mut self, index: usize, element: T) {
        let p = self.as_mut_ptr().add(index);
        if index < self.len {
            ptr::copy(p, p.add(1), self.len - index);
        }
        ptr::write(p, element);
        self.len += 1;
    }

    pub unsafe fn split_off_unchecked(&mut self, at: usize) -> Self
    where
        T: Clone,
    {
        let other_len = self.len - at;
        let mut other = StackVec {
            len: other_len,
            buff: array::MaybeUninit::uninit(),
        };

        // Unsafely `set_len` and copy items to `other`.
        unsafe {
            self.set_len(at);
            other.set_len(other_len);

            core::ptr::copy_nonoverlapping(self.as_ptr().add(at), other.as_mut_ptr(), other.len());
        }
        other
    }

    pub fn extend_with(&mut self, n: usize, value: T)
    where
        T: Clone,
    {
        let new_len = self.len + n;
        if new_len > N {
            panic!("Capacity overflow");
        }

        unsafe {
            self.extend_with_unchecked(n, value);
        }
    }

    pub unsafe fn extend_with_unchecked(&mut self, n: usize, value: T)
    where
        T: Clone,
    {
        unsafe {
            let mut ptr = self.as_mut_ptr().add(self.len());

            if n > 0 {
                for _ in 1..n {
                    core::ptr::write(ptr, value.clone());
                    ptr = ptr.add(1);
                }
                core::ptr::write(ptr, value);
            }
        }
    }

    pub unsafe fn extend_from_slice_unechecked(&mut self, other: &[T])
    where
        T: Clone,
    {
        ptr::copy_nonoverlapping(other.as_ptr(), self.as_mut_ptr().add(self.len), other.len());
        self.len += other.len();
    }
}

impl<T, const N: usize> Default for StackVec<T, N> {
    #[inline(always)]
    fn default() -> Self {
        Self::new()
    }
}

impl<T, const N: usize> IntoIterator for StackVec<T, N> {
    type Item = T;

    type IntoIter = IntoIter<T, N>;

    #[inline(always)]
    fn into_iter(self) -> Self::IntoIter {
        IntoIter { vec: self, next: 0 }
    }
}

impl<T, const N: usize> AsRef<[T]> for StackVec<T, N> {
    #[inline(always)]
    fn as_ref(&self) -> &[T] {
        self.as_slice()
    }
}

impl<T, const N: usize> AsMut<[T]> for StackVec<T, N> {
    #[inline(always)]
    fn as_mut(&mut self) -> &mut [T] {
        self.as_mut_slice()
    }
}

impl<T, const N: usize> SliceOwner for StackVec<T, N> {
    #[inline(always)]
    fn len(&self) -> usize {
        self.len
    }

    fn as_ptr(&self) -> *const Self::Item {
        todo!()
    }
}

impl<T, const N: usize> SliceOwnerMut for StackVec<T, N> {
    fn as_mut_ptr(&mut self) -> *mut Self::Item {
        unsafe { self.buff.assume_init_mut().as_mut_ptr() as *mut Self::Item } 
    }
}

impl<T, const N: usize> FromIterator<T> for StackVec<T, N> {
    fn from_iter<I>(iter: I) -> Self
    where
        I: IntoIterator<Item = T>,
    {
        let mut vec = StackVec::new();
        for item in iter {
            vec.push(item);
        }
        vec
    }
}

impl<T, const N: usize> From<[T; N]> for StackVec<T, N> {
    fn from(value: [T; N]) -> Self {
        Self {
            len: N,
            buff: value.into(),
        }
    }
}

impl<T, const N: usize> Extend<T> for StackVec<T, N> {
    fn extend<I: IntoIterator<Item = T>>(&mut self, iter: I) {
        for item in iter {
            self.push(item);
        }
    }
}

impl<T, const N: usize> Vec for StackVec<T, N> {
    #[inline(always)]
    fn new() -> Self {
        Self {
            len: 0,
            buff: array::MaybeUninit::uninit(),
        }
    }

    #[inline(always)]
    fn len(&self) -> usize {
        self.len
    }

    #[inline(always)]
    unsafe fn set_len(&mut self, new_len: usize) {
        self.len = new_len;
    }

    fn insert(&mut self, index: usize, element: Self::Item) {
        fn assert_failed(index: usize, len: usize) -> ! {
            panic!("insertion index (is {index}) should be <= len (is {len})");
        }
        if self.len == self.capacity() {
            panic!()
        }

        if index > self.len {
            assert_failed(index, self.len);
        }

        unsafe { self.insert_unchecked(index, element) }
    }

    fn push(&mut self, value: Self::Item) {
        if self.len >= N {
            panic!("capacity overflow");
        }
        unsafe { self.push_unchecked(value) };
    }

    fn append<V: Vec<Item = Self::Item>>(&mut self, other: &mut V) {
        let new_len = self.len + Vec::len(other);
        if new_len > N {
            panic!("Capacity overflow");
        }
        unsafe {
            ptr::copy_nonoverlapping(
                other.as_ptr(),
                self.as_mut_ptr().add(self.len),
                Vec::len(other),
            )
        }
        self.len = new_len;
    }

    fn split_off(&mut self, at: usize) -> Self
    where
        Self::Item: Clone,
    {
        fn assert_failed(at: usize, len: usize) -> ! {
            panic!("`at` split index (is {at}) should be <= len (is {len})");
        }

        if at > self.len() {
            assert_failed(at, self.len());
        }

        unsafe { self.split_off_unchecked(at) }
    }

    fn resize(&mut self, new_len: usize, value: Self::Item)
    where
        Self::Item: Clone,
    {
        let len = self.len();

        if new_len > len {
            self.extend_with(new_len - len, value);
        } else {
            self.truncate(new_len);
        }
    }

    fn extend_from_slice(&mut self, other: &[Self::Item])
    where
        Self::Item: Clone,
    {
        let new_len = self.len + other.len();
        if new_len > N {
            panic!("Capacity overflow");
        }
        unsafe {
            ptr::copy_nonoverlapping(other.as_ptr(), self.as_mut_ptr().add(self.len), other.len())
        }
        self.len = new_len;
    }

    fn extend_from_within<R>(&mut self, src: R)
    where
        Self::Item: Clone,
        R: RangeBounds<usize>,
    {
        let Range { start, end } =
            crate::slice::slice_range(unsafe { &*(self.as_slice() as *const [T]) }, src);
        self.extend_from_slice(unsafe {
            core::slice::from_raw_parts(self.as_ptr().add(start), end - start)
        })
    }
}

pub struct IntoIter<T, const N: usize> {
    vec: StackVec<T, N>,
    next: usize,
}

impl<T, const N: usize> Iterator for IntoIter<T, N> {
    type Item = T;

    fn next(&mut self) -> Option<Self::Item> {
        if self.next < self.vec.len() {
            let item = unsafe { ptr::read(self.vec.buff.assume_init_mut().get_unchecked_mut(self.next)) };
            self.next += 1;
            Some(item)
        } else {
            None
        }
    }
}

impl<T, const N: usize> Clone for IntoIter<T, N>
where
    T: Clone,
{
    fn clone(&self) -> Self {
        let mut vec = StackVec::new();

        if self.next < self.vec.len() {
            let s = unsafe {
                core::slice::from_raw_parts(
                    (self.vec.buff.assume_init_ref().as_ptr() as *const T).add(self.next),
                    self.vec.len() - self.next,
                )
            };
            vec.extend_from_slice(s);
        }

        Self { vec, next: 0 }
    }
}

impl<T, const N: usize> Drop for IntoIter<T, N> {
    fn drop(&mut self) {
        unsafe {
            core::ptr::drop_in_place(&mut self.vec.as_mut_slice()[self.next..]);
            self.vec.len = 0;
        }
    }
}
