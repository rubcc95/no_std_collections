use core::mem;

pub trait SliceOwner: AsRef<[Self::Item]> + IntoIterator {
    const IS_ZST: bool = mem::size_of::<Self::Item>() == 0;

    #[inline(always)]
    fn len(&self) -> usize {
        self.as_ref().len()
    }

    #[inline(always)]
    fn as_ptr(&self) -> *const Self::Item {
        self.as_ref().as_ptr()
    }
}


#[cfg(not(feature = "no_std"))]
impl<T> SliceOwner for std::vec::Vec<T> {
    #[inline(always)]
    fn len(&self) -> usize {
        self.len()
    }

    #[inline(always)]
    fn as_ptr(&self) -> *const Self::Item {
        self.as_ptr()
    }
}

impl<T, const N: usize> SliceOwner for [T; N] {
    #[inline(always)]
    fn len(&self) -> usize {
        N
    }
}
