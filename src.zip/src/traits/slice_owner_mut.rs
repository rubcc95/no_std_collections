use super::*;

pub trait SliceOwnerMut: AsRef<[Self::Item]> + AsMut<[Self::Item]> + IntoIterator {

    unsafe fn align_to<U>(&self) -> (&[Self::Item], &[U], &[Self::Item]) {
        self.as_ref().align_to()
    }

    unsafe fn align_to_mut<U>(&mut self) -> (&mut [Self::Item], &mut [U], &mut [Self::Item]) {
        self.as_mut().align_to_mut()
    }

    fn array_chunks<const N: usize>(&self) -> &[[Self::Item; N]] {
        self.as_ref().array_chunks()
    }

    fn array_chunks_mut<const N: usize>(&mut self) -> &mut [[Self::Item; N]] {
        self.as_mut().array_chunks_mut()
    }

    fn array_windows<const N: usize>(&self) -> &[[Self::Item; N]] {
        self.as_ref().array_windows()
    }

    unsafe fn as_ascii_unchecked(&self) -> &[u8] {
        self.as_ref().as_ascii_unchecked() 
    }

    fn as_bytes(&self) -> &[u8] {
        self.as_ref().as_bytes()
    }

    fn as_chunks<const N: usize>(&self) -> (&[[Self::Item; N]], &[Self::Item]) {
        self.as_ref().as_chunks()
    }

    fn as_chunks_mut<const N: usize>(&mut self) -> (&mut [[Self::Item; N]], &mut [Self::Item]) {
        self.as_mut().as_chunks_mut()
    }

    unsafe fn as_chunks_unchecked<const N: usize>(&self) -> &[[Self::Item; N]] {
        self.as_ref().as_chunks_unchecked()
    }

    unsafe fn as_chunks_unchecked_mut<const N: usize>(&mut self) -> &mut [[Self::Item; N]] {
        self.as_mut().as_chunks_unchecked_mut()
    }

    fn as_flattened(&self) -> &[Self::Item] {
        self.as_ref().as_flattened()
    }

    fn as_flattened_mut(&mut self) -> &mut [Self::Item] {
        self.as_mut().as_flattened_mut()
    }

    fn as_mut_ptr(&mut self) -> *mut Self::Item {
        self.as_mut().as_mut_ptr()
    }

    fn as_mut_ptr_range(&mut self) -> core::ops::Range<*mut Self::Item> {
        self.as_mut().as_mut_ptr_range()
    }

    fn as_ptr(&self) -> *const Self::Item {
        self.as_ref().as_ptr()
    }

    fn as_ptr_range(&self) -> core::ops::Range<*const Self::Item> {
        self.as_ref().as_ptr_range()
    }

    fn as_rchunks<const N: usize>(&self) -> &[[Self::Item; N]] {
        self.as_ref().as_rchunks()
    }

    fn as_rchunks_mut<const N: usize>(&mut self) -> &mut [[Self::Item; N]] {
        self.as_mut().as_rchunks_mut()
    }

    fn as_simd<const N: usize>(&self) -> &[[Self::Item; N]] {
        self.as_ref().as_simd()
    }

    fn as_simd_mut<const N: usize>(&mut self) -> &mut [[Self::Item; N]] {
        self.as_mut().as_simd_mut()
    }

    fn binary_search(&self, x: &Self::Item) -> Result<usize, usize>
    where
        Self::Item: Ord,
    {
        self.as_ref().binary_search(x)
    }

    fn binary_search_by<F>(&self, f: F) -> Result<usize, usize>
    where
        F: FnMut(&Self::Item) -> std::cmp::Ordering,
    {
        self.as_ref().binary_search_by(f)
    }

    fn binary_search_by_key<B, F>(&self, b: &B, f: F) -> Result<usize, usize>
    where
        F: FnMut(&Self::Item) -> B,
        B: Ord,
    {
        self.as_ref().binary_search_by_key(b, f)
    }

    fn chunk_by<F>(&self, f: F) -> &[Self::Item]
    where
        F: FnMut(&Self::Item, &Self::Item) -> bool,
    {
        unimplemented!() // Implement the chunk logic
    }

    fn chunk_by_mut<F>(&mut self, f: F) -> &mut [Self::Item]
    where
        F: FnMut(&Self::Item, &Self::Item) -> bool,
    {
        unimplemented!() // Implement the chunk logic
    }

    fn chunks(&self, size: usize) -> &[Self::Item] {
        self.as_ref().chunks(size)
    }

    fn chunks_exact(&self, size: usize) -> &[Self::Item] {
        self.as_ref().chunks_exact(size)
    }

    fn chunks_exact_mut(&mut self, size: usize) -> &mut [Self::Item] {
        self.as_mut().chunks_exact_mut(size)
    }

    fn chunks_mut(&mut self, size: usize) -> &mut [Self::Item] {
        self.as_mut().chunks_mut(size)
    }

    fn clone_from_slice(&mut self, src: &[Self::Item])
    where
        Self::Item: Clone,
    {
        self.as_mut().clone_from_slice(src)
    }

    fn concat(&self) -> Vec<Self::Item>
    where
        Self::Item: Clone,
    {
        self.as_ref().concat()
    }

    fn connect(&self, sep: &Self::Item) -> Vec<Self::Item>
    where
        Self::Item: Clone,
    {
        self.as_ref().connect(sep)
    }

    fn contains(&self, x: &Self::Item) -> bool
    where
        Self::Item: PartialEq,
    {
        self.as_ref().contains(x)
    }

    fn copy_from_slice(&mut self, src: &[Self::Item]) {
        self.as_mut().copy_from_slice(src)
    }

    fn copy_within(&mut self, src: std::ops::Range<usize>, dst: usize) {
        self.as_mut().copy_within(src, dst)
    }
    fn ends_with(&self, needle: &[Self::Item]) -> bool
    where
        Self::Item: PartialEq,
    {
        self.as_ref().ends_with(needle)
    }

    fn eq_ignore_ascii_case(&self, other: &[Self::Item]) -> bool
    where
        Self::Item: AsRef<u8>,
    {
        self.as_ref()
            .iter()
            .zip(other.iter())
            .all(|(a, b)| a.as_ref().eq_ignore_ascii_case(b.as_ref()))
    }

    fn escape_ascii(&self) -> String
    where
        Self::Item: AsRef<u8>,
    {
        self.as_ref()
            .iter()
            .flat_map(|item| item.as_ref().escape_ascii())
            .collect()
    }

    fn fill(&mut self, value: Self::Item)
    where
        Self::Item: Clone,
    {
        self.as_mut().fill(value)
    }

    fn fill_with<F>(&mut self, f: F)
    where
        F: FnMut() -> Self::Item,
    {
        self.as_mut().fill_with(f)
    }

    fn first(&self) -> Option<&Self::Item> {
        self.as_ref().first()
    }

    fn first_chunk<const N: usize>(&self) -> Option<&[Self::Item; N]> {
        self.as_ref().first_chunk()
    }

    fn first_chunk_mut<const N: usize>(&mut self) -> Option<&mut [Self::Item; N]> {
        self.as_mut().first_chunk_mut()
    }

    fn first_mut(&mut self) -> Option<&mut Self::Item> {
        self.as_mut().first_mut()
    }

    fn get(&self, index: usize) -> Option<&Self::Item> {
        self.as_ref().get(index)
    }

    fn get_many_mut<const N: usize>(&mut self, indices: [usize; N]) -> Option<[&mut Self::Item; N]> {
        self.as_mut().get_many_mut(indices)
    }

    unsafe fn get_many_unchecked_mut<const N: usize>(
        &mut self,
        indices: [usize; N],
    ) -> [&mut Self::Item; N] {
        self.as_mut().get_many_unchecked_mut(indices)
    }

    fn get_mut(&mut self, index: usize) -> Option<&mut Self::Item> {
        self.as_mut().get_mut(index)
    }

    unsafe fn get_unchecked(&self, index: usize) -> &Self::Item {
        self.as_ref().get_unchecked(index)
    }

    unsafe fn get_unchecked_mut(&mut self, index: usize) -> &mut Self::Item {
        self.as_mut().get_unchecked_mut(index)
    }

    fn into_vec(self) -> Vec<Self::Item> {
        unimplemented!() // Implementa según sea necesario
    }

    fn is_ascii(&self) -> bool
    where
        Self::Item: AsRef<u8>,
    {
        self.as_ref().iter().all(|item| item.as_ref().is_ascii())
    }

    fn is_empty(&self) -> bool {
        self.as_ref().is_empty()
    }

    fn is_sorted(&self) -> bool
    where
        Self::Item: Ord,
    {
        self.as_ref().is_sorted()
    }

    fn is_sorted_by<F>(&self, compare: F) -> bool
    where
        F: FnMut(&Self::Item, &Self::Item) -> std::cmp::Ordering,
    {
        self.as_ref().is_sorted_by(compare)
    }

    fn is_sorted_by_key<K, F>(&self, f: F) -> bool
    where
        F: FnMut(&Self::Item) -> K,
        K: Ord,
    {
        self.as_ref().is_sorted_by_key(f)
    }

    fn iter(&self) -> std::slice::Iter<Self::Item> {
        self.as_ref().iter()
    }

    fn iter_mut(&mut self) -> std::slice::IterMut<Self::Item> {
        self.as_mut().iter_mut()
    }

    fn join(&self, separator: &Self::Item) -> Vec<Self::Item>
    where
        Self::Item: Clone,
    {
        self.as_ref().join(separator)
    }

    fn last(&self) -> Option<&Self::Item> {
        self.as_ref().last()
    }

    fn last_chunk<const N: usize>(&self) -> Option<&[Self::Item; N]> {
        self.as_ref().last_chunk()
    }

    fn last_chunk_mut<const N: usize>(&mut self) -> Option<&mut [Self::Item; N]> {
        self.as_mut().last_chunk_mut()
    }

    fn last_mut(&mut self) -> Option<&mut Self::Item> {
        self.as_mut().last_mut()
    }

    fn len(&self) -> usize {
        self.as_ref().len()
    }

    fn partition_dedup(&mut self) -> (&mut [Self::Item], &mut [Self::Item])
    where
        Self::Item: PartialEq,
    {
        self.as_mut().partition_dedup()
    }

    fn partition_dedup_by<F>(&mut self, f: F) -> (&mut [Self::Item], &mut [Self::Item])
    where
        F: FnMut(&mut Self::Item, &mut Self::Item) -> bool,
    {
        self.as_mut().partition_dedup_by(f)
    }

    fn partition_dedup_by_key<K, F>(&mut self, f: F) -> (&mut [Self::Item], &mut [Self::Item])
    where
        F: FnMut(&mut Self::Item) -> K,
        K: PartialEq,
    {
        self.as_mut().partition_dedup_by_key(f)
    }

    fn partition_point<F>(&self, f: F) -> usize
    where
        F: FnMut(&Self::Item) -> bool,
    {
        self.as_ref().partition_point(f)
    }

    fn rchunks(&self, chunk_size: usize) -> std::slice::RChunks<Self::Item> {
        self.as_ref().rchunks(chunk_size)
    }

    fn rchunks_exact(&self, chunk_size: usize) -> std::slice::RChunksExact<Self::Item> {
        self.as_ref().rchunks_exact(chunk_size)
    }

    fn rchunks_exact_mut(&mut self, chunk_size: usize) -> std::slice::RChunksExactMut<Self::Item> {
        self.as_mut().rchunks_exact_mut(chunk_size)
    }

    fn rchunks_mut(&mut self, chunk_size: usize) -> std::slice::RChunksMut<Self::Item> {
        self.as_mut().rchunks_mut(chunk_size)
    }

    fn repeat(&self, n: usize) -> Vec<Self::Item>
    where
        Self::Item: Clone,
    {
        self.as_ref().repeat(n)
    }

    fn reverse(&mut self) {
        self.as_mut().reverse()
    }

    fn rotate_left(&mut self, mid: usize) {
        self.as_mut().rotate_left(mid)
    }

    fn rotate_right(&mut self, mid: usize) {
        self.as_mut().rotate_right(mid)
    }
    // Continúa con los demás métodos
}


impl<T, const N: usize> SliceOwnerMut for [T; N] {}
