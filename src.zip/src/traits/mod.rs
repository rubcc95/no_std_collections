pub mod vec;

mod map;
mod map_into;
mod slice_owner;
mod slice_owner_mut;
mod vec_for;

pub use filter_map::FilterMap;
pub use map::Map;
pub use map::MapInto;
pub use slice_owner::SliceOwner;
pub use slice_owner_mut::SliceOwnerMut;
pub use vec::Vec;
pub use vec_for::VecFor;

mod filter_map {
    use super::{SliceOwner, VecFor};
    use crate::traits::*;

    pub trait FilterMap {
        type Item;
        type Output<T>: SliceOwnerMut<Item = T>;

        fn filter_map<'a, T, F: FnMut(&'a Self::Item) -> Option<T>>(
            &'a self,
            f: F,
        ) -> Self::Output<T>;
    }

    impl<V: VecFor + SliceOwner> FilterMap for V {
        type Item = V::Item;
        type Output<T> = V::Vec<T>;

        fn filter_map<'a, T, F: FnMut(&'a Self::Item) -> Option<T>>(
            &'a self,
            mut f: F,
        ) -> Self::Output<T> {
            let mut res: V::Vec<T> = Vec::new();
            for item in self.as_ref().iter() {
                if let Some(item) = f(item) {
                    res.push(item);
                }
            }

            res
        }
    }
}
