use crate::StackVec;

pub unsafe trait VecFor {
    type Vec<T>: crate::traits::Vec<Item = T>;

    fn get_vec_with_capacity_for<T>(&self) -> Self::Vec<T>;        
}

unsafe impl<In, const N: usize> VecFor for [In; N] {
    #[cfg(feature = "no_std")]
    type Vec<Out> = StackVec<Out, N>;
    #[cfg(not(feature = "no_std"))]
    type Vec<Out> = Vec<Out>;

    fn get_vec_with_capacity_for<Out>(&self) -> Self::Vec<Out> {
        #[cfg(feature = "no_std")]
        {
            Self::Vec::new()
        }

        #[cfg(not(feature = "no_std"))]
        {
            Self::Vec::with_capacity(N)
        }
    }
}

unsafe impl<In, const N: usize> VecFor for StackVec<In, N> {
    #[cfg(feature = "no_std")]
    type Vec<Out> = StackVec<Out, N>;
    #[cfg(not(feature = "no_std"))]
    type Vec<Out> = Vec<Out>;

    fn get_vec_with_capacity_for<Out>(&self) -> Self::Vec<Out> {
        #[cfg(feature = "no_std")]
        {
            Self::Vec::new()
        }

        #[cfg(not(feature = "no_std"))]
        {
            Self::Vec::with_capacity(N)
        }
    }
}

#[cfg(not(feature = "no_std"))]
unsafe impl<In> VecFor for Vec<In> {
    type Vec<Out> = Vec<Out>;

    fn get_vec_with_capacity_for<Out>(&self) -> Self::Vec<Out> {
        Self::Vec::with_capacity(self.len())
    }
}

#[cfg(not(feature = "no_std"))]
unsafe impl<In> VecFor for [In] {
    type Vec<Out> = Vec<Out>;

    fn get_vec_with_capacity_for<Out>(&self) -> Self::Vec<Out> {
        Self::Vec::with_capacity(self.len())
    }
}

unsafe impl<'a, V: VecFor> VecFor for &'a V{
    type Vec<T> = V::Vec<T>;

    fn get_vec_with_capacity_for<T>(&self) -> Self::Vec<T> {
        V::get_vec_with_capacity_for(*self)
    }
}


unsafe impl<'a, V: VecFor> VecFor for &'a mut V{
    type Vec<T> = V::Vec<T>;

    fn get_vec_with_capacity_for<T>(&self) -> Self::Vec<T> {
        V::get_vec_with_capacity_for(*self)
    }
}
