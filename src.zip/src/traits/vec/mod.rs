mod drain;
pub use drain::Drain;

use super::*;

use core::mem;
use core::ops::{Range, RangeBounds};
use core::ptr;
use core::slice;


pub trait Vec: SliceOwnerMut + Default + Extend<Self::Item> + FromIterator<Self::Item> {
    fn new() -> Self;

    fn len(&self) -> usize;

    #[inline(always)]
    fn into_raw_parts(mut self) -> (*mut Self::Item, usize, usize) {
        (self.as_mut_ptr(), Vec::len(&self), self.capacity())
    }

    fn capacity(&self) -> usize {
        SliceOwner::len(self)
    }

    #[inline(always)]
    fn as_slice(&self) -> &[Self::Item] {
        self.as_ref()
    }

    #[inline(always)]
    fn as_mut_slice(&mut self) -> &mut [Self::Item] {
        self.as_mut()
    }

    #[inline(always)]
    fn truncate(&mut self, len: usize) {
        if len > Vec::len(self) {
            return;
        }

        unsafe { self.truncate_unchecked(len) };
    }

    unsafe fn truncate_unchecked(&mut self, len: usize) {
        let remaining_len = Vec::len(self).unchecked_sub(len);
        let s =
            ptr::slice_from_raw_parts_mut(self.as_mut().as_mut_ptr().add(len), remaining_len);
        self.set_len(len);
        ptr::drop_in_place(s);
    }

    unsafe fn set_len(&mut self, new_len: usize);

    unsafe fn swap_remove_unchecked(&mut self, index: usize) -> Self::Item {
        let value = ptr::read(self.as_ptr().add(index));
        let base_ptr = self.as_mut_ptr();
        let next_len = Vec::len(self).unchecked_sub(1);
        ptr::copy(base_ptr.add(next_len), base_ptr.add(index), 1);
        self.set_len(next_len);
        value
    }

    #[inline]
    fn swap_remove(&mut self, index: usize) -> Self::Item {
        fn assert_failed(index: usize, len: usize) -> ! {
            panic!("swap_remove index (is {index}) should be < len (is {len})");
        }

        if index >= Vec::len(self) {
            assert_failed(index, Vec::len(self));
        }

        unsafe { self.swap_remove_unchecked(index) }
    }

    fn drain<R>(&mut self, range: R) -> Drain<Self>
    where
        R: RangeBounds<usize>,
    {
        let Range { start, end } = crate::slice::slice_range(self.as_ref(), range);
        drain::Drain {
            tail_start: end,
            tail_len: Vec::len(self) - end,
            iter: unsafe {
                slice::from_raw_parts(self.as_ptr().add(start), end - start).iter()
            },
            vec: ptr::NonNull::from(self),
        }
    }

    fn insert(&mut self, index: usize, element: Self::Item);

    unsafe fn remove_unchecked(&mut self, index: usize) -> Self::Item {
        let len = Vec::len(self);

        unsafe {
            self.set_len(len - 1);

            let ptr = self.as_mut_ptr().add(index);
            let ret = ptr::read(ptr);
            ptr::copy(ptr.add(1), ptr, Vec::len(self) - index);
            ret
        }
    }

    #[inline]
    fn remove(&mut self, index: usize) -> Self::Item {
        fn assert_failed(index: usize, len: usize) -> ! {
            panic!("removal index (is {index}) should be < len (is {len})");
        }

        if index >= Vec::len(self) {
            assert_failed(index, Vec::len(self));
        }

        unsafe { self.remove_unchecked(index) }
    }

    #[inline]
    fn retain<F>(&mut self, mut f: F)
    where
        F: FnMut(&Self::Item) -> bool,
    {
        self.retain_mut(|elem| f(elem));
    }

    fn retain_mut<F>(&mut self, mut f: F)
    where
        F: FnMut(&mut Self::Item) -> bool,
    {
        let original_len = Vec::len(self);
        unsafe { self.set_len(0) };

        struct BackshiftOnDrop<'a, V: Vec> {
            v: &'a mut V,
            processed_len: usize,
            deleted_cnt: usize,
            original_len: usize,
        }

        impl<V: Vec> Drop for BackshiftOnDrop<'_, V> {
            fn drop(&mut self) {
                if self.deleted_cnt > 0 {
                    // SAFETY: Trailing unchecked items must be valid since we never touch them.
                    unsafe {
                        ptr::copy(
                            self.v.as_ptr().add(self.processed_len),
                            self.v
                                .as_mut_ptr()
                                .add(self.processed_len - self.deleted_cnt),
                            self.original_len - self.processed_len,
                        );
                    }
                }
                // SAFETY: After filling holes, all items are in contiguous memory.
                unsafe {
                    self.v.set_len(self.original_len - self.deleted_cnt);
                }
            }
        }

        let mut g = BackshiftOnDrop {
            v: self,
            processed_len: 0,
            deleted_cnt: 0,
            original_len,
        };

        fn process_loop<F, V, const DELETED: bool>(
            original_len: usize,
            f: &mut F,
            g: &mut BackshiftOnDrop<'_, V>,
        ) where
            V: Vec,
            F: FnMut(&mut V::Item) -> bool,
        {
            while g.processed_len != original_len {
                let cur = unsafe { &mut *g.v.as_mut_ptr().add(g.processed_len) };
                if !f(cur) {
                    g.processed_len += 1;
                    g.deleted_cnt += 1;
                    unsafe { ptr::drop_in_place(cur) };
                    if DELETED {
                        continue;
                    } else {
                        break;
                    }
                }
                if DELETED {
                    unsafe {
                        let hole_slot = g.v.as_mut_ptr().add(g.processed_len - g.deleted_cnt);
                        ptr::copy_nonoverlapping(cur, hole_slot, 1);
                    }
                }
                g.processed_len += 1;
            }
        }

        process_loop::<F, Self, false>(original_len, &mut f, &mut g);

        process_loop::<F, Self, true>(original_len, &mut f, &mut g);

        drop(g);
    }

    fn dedup_by_key<F, K>(&mut self, mut key: F)
    where
        F: FnMut(&mut Self::Item) -> K,
        K: PartialEq,
    {
        self.dedup_by(|a, b| key(a) == key(b))
    }

    fn dedup_by<F>(&mut self, mut same_bucket: F)
    where
        F: FnMut(&mut Self::Item, &mut Self::Item) -> bool,
    {
        let len = Vec::len(self);
        if len <= 1 {
            return;
        }

        let mut first_duplicate_idx: usize = 1;
        let start = self.as_mut_ptr();
        while first_duplicate_idx != len {
            let found_duplicate = unsafe {
                // SAFETY: first_duplicate always in range [1..len)
                // Note that we start iteration from 1 so we never overflow.
                let prev = start.add(first_duplicate_idx.wrapping_sub(1));
                let current = start.add(first_duplicate_idx);
                // We explicitly say in docs that references are reversed.
                same_bucket(&mut *current, &mut *prev)
            };
            if found_duplicate {
                break;
            }
            first_duplicate_idx += 1;
        }

        if first_duplicate_idx == len {
            return;
        }

        struct FillGapOnDrop<'a, V: Vec> {
            read: usize,
            write: usize,
            vec: &'a mut V,
        }

        impl<'a, V: Vec> Drop for FillGapOnDrop<'a, V> {
            fn drop(&mut self) {
                unsafe {
                    let ptr = self.vec.as_mut_ptr();
                    let len = Vec::len(self.vec);
                    let items_left = len.wrapping_sub(self.read);

                    let dropped_ptr = ptr.add(self.write);
                    let valid_ptr = ptr.add(self.read);

                    ptr::copy(valid_ptr, dropped_ptr, items_left);

                    let dropped = self.read.wrapping_sub(self.write);

                    self.vec.set_len(len - dropped);
                }
            }
        }
        let mut gap = FillGapOnDrop {
            read: first_duplicate_idx + 1,
            write: first_duplicate_idx,
            vec: self,
        };
        unsafe {
            ptr::drop_in_place(start.add(first_duplicate_idx));
        }
        unsafe {
            while gap.read < len {
                let read_ptr = start.add(gap.read);
                let prev_ptr = start.add(gap.write.wrapping_sub(1));

                let found_duplicate = same_bucket(&mut *read_ptr, &mut *prev_ptr);
                if found_duplicate {
                    gap.read += 1;
                    ptr::drop_in_place(read_ptr);
                } else {
                    let write_ptr = start.add(gap.write);

                    /* read_ptr cannot be equal to write_ptr because at this point
                         * we guaranteed to skip at least one element (before loop starts).
                         */
                    ptr::copy_nonoverlapping(read_ptr, write_ptr, 1);

                    /* We have filled that place, so go further */
                    gap.write += 1;
                    gap.read += 1;
                }
            }

            gap.vec.set_len(gap.write);
            mem::forget(gap);
        }
    }

    fn push(&mut self, value: Self::Item);

    unsafe fn pop_unchecked(&mut self) -> Self::Item {
        self.set_len(Vec::len(self).unchecked_sub(1));
        ptr::read(self.as_ptr().add(Vec::len(self)))
    }

    #[inline]
    fn pop(&mut self) -> Option<Self::Item> {
        if Vec::len(self) == 0 {
            None
        } else {
            unsafe { Some(self.pop_unchecked()) }
        }
    }

    fn append<V: Vec<Item = Self::Item>>(&mut self, other: &mut V);

    fn clear(&mut self) {
        let elems: *mut _ = self.as_mut();
        unsafe {
            self.set_len(0);
            ptr::drop_in_place(elems);
        }
    }

    #[inline]
    fn is_empty(&self) -> bool {
        Vec::len(self) == 0
    }

    fn split_off(&mut self, at: usize) -> Self
    where
        Self::Item: Clone;

    fn resize(&mut self, new_len: usize, value: Self::Item)
    where
        Self::Item: Clone;

    fn extend_from_slice(&mut self, other: &[Self::Item])
    where
        Self::Item: Clone;

    // fn extend_with(&mut self, n: usize, value: Self::Item)
    // where
    //     Self::Item: Clone;

    fn extend_from_within<R>(&mut self, src: R)
    where
        Self::Item: Clone,
        R: RangeBounds<usize>;
}

#[cfg(not(feature = "no_std"))]
impl<T> Vec for std::vec::Vec<T> {
    #[inline(always)]
    fn new() -> Self {
        Self::new()
    }

    #[inline(always)]
    fn len(&self) -> usize {
        self.len()
    }

    #[inline(always)]
    unsafe fn set_len(&mut self, new_len: usize) {
        self.set_len(new_len)
    }

    #[inline(always)]
    fn insert(&mut self, index: usize, element: Self::Item) {
        self.insert(index, element)
    }

    #[inline(always)]
    fn push(&mut self, value: Self::Item) {
        self.push(value)
    }

    fn append<V: Vec<Item = Self::Item>>(&mut self, other: &mut V) {
        unsafe {
            self.extend(other.as_ref().into_iter().map(|a| ptr::read(a)));
            other.set_len(0)
        };
    }

    #[inline(always)]
    fn split_off(&mut self, at: usize) -> Self {
        self.split_off(at)
    }

    fn resize(&mut self, new_len: usize, value: Self::Item)
    where
        T: Clone,
    {
        self.resize(new_len, value);
    }

    fn extend_from_slice(&mut self, other: &[Self::Item])
    where
        T: Clone,
    {
        self.extend_from_slice(other);
    }

    fn extend_from_within<R>(&mut self, src: R)
    where
        T: Clone,
        R: RangeBounds<usize>,
    {
        self.extend_from_within(src)
    }
}

