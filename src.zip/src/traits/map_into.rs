use crate::StackVec;

use super::Map;

pub trait MapInto {
    type Item;
    type Output<T>: super::SliceOwnerMut<Item = T>;

    fn map_into<T, F: FnMut(Self::Item) -> T>(self, f: F) -> Self::Output<T>;
}

impl<In, const N: usize> MapInto for [In; N] {
    type Item = In;

    type Output<Out> = [Out; N];

    fn map_into<Out, F: FnMut(Self::Item) -> Out>(self, f: F) -> Self::Output<Out> {
        self.map(f)
    }
}

#[cfg(not(feature = "no_std"))]
impl<In> MapInto for Vec<In> {
    type Item = In;

    type Output<Out> = Vec<Out>;

    fn map_into<Out, F: FnMut(Self::Item) -> Out>(self, f: F) -> Self::Output<Out> {
        self.into_iter().map(f).collect()
    }
}

impl<In, const N: usize> MapInto for StackVec<In, N> {
    type Item = In;

    #[cfg(feature = "no_std")]
    type Output<Out> = StackVec<Out, N>;
    #[cfg(not(feature = "no_std"))]
    type Output<Out> = Vec<Out>;

    #[cfg(feature = "no_std")]
    fn map_into<Out, F: FnMut(Self::Item) -> Out>(self, f: F) -> Self::Output<Out> {
        self.map(f)
    }

    #[cfg(not(feature = "no_std"))]
    fn map_into<Out, F: FnMut(Self::Item) -> Out>(self, mut f: F) -> Self::Output<Out> {
        let mut res = Vec::with_capacity(N);
        for index in 0..N {
            unsafe {
                *res.get_unchecked_mut(index) =
                    f(std::ptr::read(self.as_ref().get_unchecked(index)))
            };
        }
        res
    }
}

impl<'a, M: Map> MapInto for &'a M {
    type Item = &'a M::Item;

    type Output<T> = M::Output<T>;

    fn map_into<T, F: FnMut(Self::Item) -> T>(self, f: F) -> Self::Output<T> {
        Map::map(self, f)
    }
}

impl<'a, M: Map> MapInto for &'a mut M {
    type Item = &'a M::Item;

    type Output<T> = M::Output<T>;

    fn map_into<T, F: FnMut(Self::Item) -> T>(self, f: F) -> Self::Output<T> {
        Map::map(self, f)
    }
}
