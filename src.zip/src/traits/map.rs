use crate::traits;
use crate::StackVec;

pub use super::map_into::MapInto;

pub trait Map {
    type Item;
    type Output<T>: traits::SliceOwnerMut<Item = T>;

    fn map<'a, T, F: FnMut(&'a Self::Item) -> T>(&'a self, f: F) -> Self::Output<T>;
}

impl<In, const N: usize> Map for [In; N] {
    type Item = In;

    type Output<Out> = [Out; N];

    fn map<'a, Out, F: FnMut(&'a Self::Item) -> Out>(&'a self, mut f: F) -> Self::Output<Out> {
        let mut res = crate::array::MaybeUninit::<Out, N>::uninit();

        for index in 0..N {
            unsafe {
                *res.assume_init_mut().get_unchecked_mut(index) = f(self.get_unchecked(index))
            };
        }
        unsafe { res.assume_init() }
    }
}

#[cfg(not(feature = "no_std"))]
impl<In> Map for Vec<In> {
    type Item = In;

    type Output<Out> = Vec<Out>;

    fn map<'a, Out, F: FnMut(&'a Self::Item) -> Out>(&'a self, f: F) -> Self::Output<Out> {
        self.into_iter().map(f).collect()
    }
}

impl<In, const N: usize> Map for StackVec<In, N> {
    type Item = In;

    #[cfg(feature = "no_std")]
    type Output<Out> = StackVec<Out, N>;
    #[cfg(not(feature = "no_std"))]
    type Output<Out> = Vec<Out>;

    #[cfg(feature = "no_std")]
    fn map<'a, Out, F: FnMut(&'a Self::Item) -> Out>(&'a self, f: F) -> Self::Output<Out> {
        StackVec::map_ref(self, f)
    }

    #[cfg(not(feature = "no_std"))]
    fn map<'a, Out, F: FnMut(&'a Self::Item) -> Out>(&'a self, mut f: F) -> Self::Output<Out> {
        let mut res = Vec::with_capacity(N);
        for index in 0..N {
            unsafe { *res.get_unchecked_mut(index) = f(self.as_ref().get_unchecked(index)) };
        }
        res
    }
}


impl<'a, M: Map> Map for &'a M {
    type Item = M::Item;

    type Output<T> = M::Output<T>;
    
    fn map<'b, T, F: FnMut(&'b Self::Item) -> T>(&'b self, f: F) -> Self::Output<T> {
        M::map(*self, f)
    }
}

impl<'a, M: Map> Map for &'a mut M {
    type Item = M::Item;

    type Output<T> = M::Output<T>;
    
    fn map<'b, T, F: FnMut(&'b Self::Item) -> T>(&'b self, f: F) -> Self::Output<T> {
        M::map(*self, f)
    }
}

