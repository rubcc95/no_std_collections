pub fn slice_range<T, R: core::ops::RangeBounds<usize>>(
    slice: &[T],
    bounds: R,
) -> core::ops::Range<usize> {
    let start = match bounds.start_bound() {
        core::ops::Bound::Included(&start) => start,
        core::ops::Bound::Excluded(start) => start + 1,
        core::ops::Bound::Unbounded => 0,
    };

    let end = match bounds.end_bound() {
        core::ops::Bound::Included(end) => end.checked_add(1).unwrap_or_else(|| panic!()),
        core::ops::Bound::Excluded(&end) => end,
        core::ops::Bound::Unbounded => slice.len(),
    };

    if start > end {
        panic!();
    }
    if end > slice.len() {
        panic!();
    }

    start..end
}
