use core::fmt;
use core::iter::FusedIterator;
use core::mem;
use core::num::NonZero;
use core::ops::{Deref, DerefMut};
use core::ptr;
use crate::traits::{SliceOwner, Vec};

pub struct BinaryHeap<V> {
    data: V,
}

pub struct PeekMut<'a, V: Vec<Item: 'a + Ord>> {
    heap: &'a mut BinaryHeap<V>,
    original_len: Option<NonZero<usize>>,
} 

impl<V: Vec<Item: Ord + fmt::Debug>> fmt::Debug for PeekMut<'_, V> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("PeekMut")
            .field(&self.heap.data.as_ref()[0])
            .finish()
    }
}

impl<V: Vec<Item: Ord>> Drop for PeekMut<'_, V> {
    fn drop(&mut self) {
        if let Some(original_len) = self.original_len {
            unsafe { self.heap.data.set_len(original_len.get()) };
            unsafe { self.heap.sift_down(0) };
        }
    }
}

impl<V: Vec<Item: Ord>> Deref for PeekMut<'_, V> {
    type Target = V::Item;
    fn deref(&self) -> &V::Item {
        debug_assert!(!self.heap.is_empty());
        unsafe { self.heap.data.as_ref().get_unchecked(0) }
    }
}

impl<V: Vec<Item: Ord>> DerefMut for PeekMut<'_, V> {
    fn deref_mut(&mut self) -> &mut V::Item {
        debug_assert!(!self.heap.is_empty());

        let len = self.heap.len();
        if len > 1 {
            // Here we preemptively leak all the rest of the underlying vector
            // after the currently max element. If the caller mutates the &mut T
            // we're about to give themnd then leaks the PeekMutll these
            // elements will remain leaked. If they don't leak the PeekMut, then
            // either Drop or PeekMut::pop will un-leak the vector elements.
            //
            // This is technique is described throughout several other places in
            // the standard library as "leak amplification".
            unsafe {
                // SAFETY: len > 1 so len != 0.
                self.original_len = Some(NonZero::new_unchecked(len));
                // SAFETY: len > 1 so all this does for now is leak elements,
                // which is safe.
                self.heap.data.set_len(1);
            }
        }

        // SAFE: PeekMut is only instantiated for non-empty heaps
        unsafe { self.heap.data.as_mut().get_unchecked_mut(0) }
    }
}

impl<'a, V: Vec<Item: Ord>> PeekMut<'a, V> {
    pub fn pop(mut this: PeekMut<'a, V>) -> V::Item {
        if let Some(original_len) = this.original_len.take() {
            // SAFETY: This is how many elements were in the Vec at the time of
            // the BinaryHeap::peek_mut call.
            unsafe { this.heap.data.set_len(original_len.get()) };

            // Unlike in Drop, here we don't also need to do a sift_down even if
            // the caller could've mutated the element. It is removed from the
            // heap on the next line and pop() is not sensitive to its value.
        }
        this.heap.data.pop().unwrap()
    }
}

impl<V: Clone> Clone for BinaryHeap<V> {
    fn clone(&self) -> Self {
        BinaryHeap {
            data: self.data.clone(),
        }
    }

    fn clone_from(&mut self, source: &Self) {
        self.data.clone_from(&source.data);
    }
}

impl<T: Default> Default for BinaryHeap<T> {
    /// Creates an empty `BinaryHeap<T>`.
    #[inline]
    fn default() -> BinaryHeap<T> {
        BinaryHeap { data: T::default() }
    }
}

impl<T: Vec<Item:fmt::Debug>> fmt::Debug for BinaryHeap<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_list().entries(self.iter()).finish()
    }
}

struct RebuildOnDrop<'a, T: Vec<Item: Ord>> {
    heap: &'a mut BinaryHeap<T>,
    rebuild_from: usize,
}

impl<T: Vec<Item: Ord>> Drop for RebuildOnDrop<'_, T> {
    fn drop(&mut self) {
        self.heap.rebuild_tail(self.rebuild_from);
    }
}

impl<V: Vec> BinaryHeap<V> {
    pub fn new() -> BinaryHeap<V> {
        BinaryHeap { data: V::new() }
    }
}

impl<T: Vec<Item: Ord>> BinaryHeap<T> {
    pub fn peek_mut(&mut self) -> Option<PeekMut<'_, T>> {
        if self.is_empty() {
            None
        } else {
            Some(PeekMut {
                heap: self,
                original_len: None,
            })
        }
    }

    pub fn pop(&mut self) -> Option<T::Item> {
        self.data.pop().map(|mut item| {
            if !self.is_empty() {
                mem::swap(&mut item, &mut self.data.as_mut()[0]);
                // SAFETY: !self.is_empty() means that self.len() > 0
                unsafe { self.sift_down_to_bottom(0) };
            }
            item
        })
    }

    pub fn push(&mut self, item: T::Item) {
        let old_len = self.len();
        self.data.push(item);
        // SAFETY: Since we pushed a new item it means that
        //  old_len = self.len() - 1 < self.len()
        unsafe { self.sift_up(0, old_len) };
    }

    pub fn into_sorted_vec(mut self) -> T {
        let mut end = self.len();
        while end > 1 {
            end -= 1;
            // SAFETY: `end` goes from `self.len() - 1` to 1 (both included),
            //  so it's always a valid index to access.
            //  It is safe to access index 0 (i.e. `ptr`), because
            //  1 <= end < self.len(), which means self.len() >= 2.
            unsafe {
                let ptr = self.data.as_mut_ptr();
                ptr::swap(ptr, ptr.add(end));
            }
            // SAFETY: `end` goes from `self.len() - 1` to 1 (both included) so:
            //  0 < 1 <= end <= self.len() - 1 < self.len()
            //  Which means 0 < end and end < self.len().
            unsafe { self.sift_down_range(0, end) };
        }
        self.into_vec()
    }

    unsafe fn sift_up(&mut self, start: usize, pos: usize) -> usize {
        // Take out the value at `pos` and create a hole.
        // SAFETY: The caller guarantees that pos < self.len()
        let mut hole = unsafe { Hole::new(self.data.as_mut(), pos) };

        while hole.pos() > start {
            let parent = (hole.pos() - 1) / 2;

            // SAFETY: hole.pos() > start >= 0, which means hole.pos() > 0
            //  and so hole.pos() - 1 can't underflow.
            //  This guarantees that parent < hole.pos() so
            //  it's a valid index and also != hole.pos().
            if hole.element() <= unsafe { hole.get(parent) } {
                break;
            }

            // SAFETY: Same as above
            unsafe { hole.move_to(parent) };
        }

        hole.pos()
    }

    /// Take an element at `pos` and move it down the heap,
    /// while its children are larger.
    ///
    /// # Safety
    ///
    /// The caller must guarantee that `pos < end <= self.len()`.
    unsafe fn sift_down_range(&mut self, pos: usize, end: usize) {
        // SAFETY: The caller guarantees that pos < end <= self.len().
        let mut hole = unsafe { Hole::new(self.data.as_mut(), pos) };
        let mut child = 2 * hole.pos() + 1;

        // Loop invariant: child == 2 * hole.pos() + 1.
        while child <= end.saturating_sub(2) {
            // compare with the greater of the two children
            // SAFETY: child < end - 1 < self.len() and
            //  child + 1 < end <= self.len(), so they're valid indexes.
            //  child == 2 * hole.pos() + 1 != hole.pos() and
            //  child + 1 == 2 * hole.pos() + 2 != hole.pos().
            // FIXME: 2 * hole.pos() + 1 or 2 * hole.pos() + 2 could overflow
            //  if T is a ZST
            child += unsafe { hole.get(child) <= hole.get(child + 1) } as usize;

            // if we are already in order, stop.
            // SAFETY: child is now either the old child or the old child+1
            //  We already proven that both are < self.len() and != hole.pos()
            if hole.element() >= unsafe { hole.get(child) } {
                return;
            }

            // SAFETY: same as above.
            unsafe { hole.move_to(child) };
            child = 2 * hole.pos() + 1;
        }

        // SAFETY: && short circuit, which means that in the
        //  second condition it's already true that child == end - 1 < self.len().
        if child == end - 1 && hole.element() < unsafe { hole.get(child) } {
            // SAFETY: child is already proven to be a valid index and
            //  child == 2 * hole.pos() + 1 != hole.pos().
            unsafe { hole.move_to(child) };
        }
    }

    /// # Safety
    ///
    /// The caller must guarantee that `pos < self.len()`.
    unsafe fn sift_down(&mut self, pos: usize) {
        let len = self.len();
        // SAFETY: pos < len is guaranteed by the caller and
        //  obviously len = self.len() <= self.len().
        unsafe { self.sift_down_range(pos, len) };
    }

    /// Take an element at `pos` and move it all the way down the heap,
    /// then sift it up to its position.
    ///
    /// Note: This is faster when the element is known to be large / should
    /// be closer to the bottom.
    ///
    /// # Safety
    ///
    /// The caller must guarantee that `pos < self.len()`.
    unsafe fn sift_down_to_bottom(&mut self, mut pos: usize) {
        let end = self.len();
        let start = pos;

        // SAFETY: The caller guarantees that pos < self.len().
        let mut hole = unsafe { Hole::new(self.data.as_mut(), pos) };
        let mut child = 2 * hole.pos() + 1;

        // Loop invariant: child == 2 * hole.pos() + 1.
        while child <= end.saturating_sub(2) {
            // SAFETY: child < end - 1 < self.len() and
            //  child + 1 < end <= self.len(), so they're valid indexes.
            //  child == 2 * hole.pos() + 1 != hole.pos() and
            //  child + 1 == 2 * hole.pos() + 2 != hole.pos().
            // FIXME: 2 * hole.pos() + 1 or 2 * hole.pos() + 2 could overflow
            //  if T is a ZST
            child += unsafe { hole.get(child) <= hole.get(child + 1) } as usize;

            // SAFETY: Same as above
            unsafe { hole.move_to(child) };
            child = 2 * hole.pos() + 1;
        }

        if child == end - 1 {
            // SAFETY: child == end - 1 < self.len(), so it's a valid index
            //  and child == 2 * hole.pos() + 1 != hole.pos().
            unsafe { hole.move_to(child) };
        }
        pos = hole.pos();
        drop(hole);

        // SAFETY: pos is the position in the hole and was already proven
        //  to be a valid index.
        unsafe { self.sift_up(start, pos) };
    }

    /// Rebuild assuming data[0..start] is still a proper heap.
    fn rebuild_tail(&mut self, start: usize) {
        if start == self.len() {
            return;
        }

        let tail_len = self.len() - start;

        #[inline(always)]
        fn log2_fast(x: usize) -> usize {
            (usize::BITS - x.leading_zeros() - 1) as usize
        }

        // `rebuild` takes O(self.len()) operations
        // and about 2 * self.len() comparisons in the worst case
        // while repeating `sift_up` takes O(tail_len * log(start)) operations
        // and about 1 * tail_len * log_2(start) comparisons in the worst case,
        // assuming start >= tail_len. For larger heaps, the crossover point
        // no longer follows this reasoning and was determined empirically.
        let better_to_rebuild = if start < tail_len {
            true
        } else if self.len() <= 2048 {
            2 * self.len() < tail_len * log2_fast(start)
        } else {
            2 * self.len() < tail_len * 11
        };

        if better_to_rebuild {
            self.rebuild();
        } else {
            for i in start..self.len() {
                // SAFETY: The index `i` is always less than self.len().
                unsafe { self.sift_up(0, i) };
            }
        }
    }

    fn rebuild(&mut self) {
        let mut n = self.len() / 2;
        while n > 0 {
            n -= 1;
            // SAFETY: n starts from self.len() / 2 and goes down to 0.
            //  The only case when !(n < self.len()) is if
            //  self.len() == 0, but it's ruled out by the loop condition.
            unsafe { self.sift_down(n) };
        }
    }

    pub fn append(&mut self, other: &mut Self) {
        if self.len() < other.len() {
            mem::swap(self, other);
        }

        let start = Vec::len(&self.data);

        self.data.append(&mut other.data);

        self.rebuild_tail(start);
    }

    pub fn drain_sorted(&mut self) -> DrainSorted<'_, T> {
        DrainSorted { inner: self }
    }

    pub fn retain<F>(&mut self, mut f: F)
    where
        F: FnMut(&T::Item) -> bool,
    {
        // rebuild_start will be updated to the first touched element belownd the rebuild will
        // only be done for the tail.
        let mut guard = RebuildOnDrop {
            rebuild_from: self.len(),
            heap: self,
        };
        let mut i = 0;

        guard.heap.data.retain(|e| {
            let keep = f(e);
            if !keep && i < guard.rebuild_from {
                guard.rebuild_from = i;
            }
            i += 1;
            keep
        });
    }
}

impl<T: Vec> BinaryHeap<T> {
    pub fn iter(&self) -> core::slice::Iter<'_, T::Item> where T: Vec {
        self.data.as_ref().iter()
    }

    pub fn into_iter_sorted(self) -> IntoIterSorted<T> {
        IntoIterSorted { inner: self }
    }

    pub fn peek(&self) -> Option<&T::Item> {
        self.data.as_ref().get(0)
    }

    pub fn capacity(&self) -> usize {
        self.data.capacity()
    }    

    pub fn as_slice(&self) -> &[T::Item] {
        self.data.as_slice()
    }

    pub fn into_vec(self) -> T {
        self.data
    }

    pub fn len(&self) -> usize {
        Vec::len(&self.data)
    }

    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    pub fn clear(&mut self) {
        self.data.clear();
    }
}

/// Hole represents a hole in a slice i.e.n index without valid value
/// (because it was moved from or duplicated).
/// In drop, `Hole` will restore the slice by filling the hole
/// position with the value that was originally removed.
struct Hole<'a, T: 'a> {
    data: &'a mut [T],
    elt: mem::ManuallyDrop<T>,
    pos: usize,
}

impl<'a, T> Hole<'a, T> {
    /// Create a new `Hole` at index `pos`.
    ///
    /// Unsafe because pos must be within the data slice.
    #[inline]
    unsafe fn new(data: &'a mut [T], pos: usize) -> Self {
        debug_assert!(pos < data.len());
        // SAFE: pos should be inside the slice
        let elt = unsafe { ptr::read(data.get_unchecked(pos)) };
        Hole {
            data,
            elt: mem::ManuallyDrop::new(elt),
            pos,
        }
    }

    #[inline]
    fn pos(&self) -> usize {
        self.pos
    }

    /// Returns a reference to the element removed.
    #[inline]
    fn element(&self) -> &T {
        &self.elt
    }

    /// Returns a reference to the element at `index`.
    ///
    /// Unsafe because index must be within the data slice and not equal to pos.
    #[inline]
    unsafe fn get(&self, index: usize) -> &T {
        debug_assert!(index != self.pos);
        debug_assert!(index < self.data.len());
        unsafe { self.data.get_unchecked(index) }
    }

    /// Move hole to new location
    ///
    /// Unsafe because index must be within the data slice and not equal to pos.
    #[inline]
    unsafe fn move_to(&mut self, index: usize) {
        debug_assert!(index != self.pos);
        debug_assert!(index < self.data.len());
        unsafe {
            let ptr = self.data.as_mut_ptr();
            let index_ptr: *const _ = ptr.add(index);
            let hole_ptr = ptr.add(self.pos);
            ptr::copy_nonoverlapping(index_ptr, hole_ptr, 1);
        }
        self.pos = index;
    }
}

impl<T> Drop for Hole<'_, T> {
    #[inline]
    fn drop(&mut self) {
        // fill the hole again
        unsafe {
            let pos = self.pos;
            ptr::copy_nonoverlapping(&*self.elt, self.data.get_unchecked_mut(pos), 1);
        }
    }
}

#[derive(Clone)]
pub struct IntoIterSorted<T> {
    inner: BinaryHeap<T>,
}

impl<T: Vec<Item: fmt::Debug>> fmt::Debug for IntoIterSorted<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("IntoIterSorted").field("inner", &self.inner).finish()
    }
}

impl<T: Vec<Item: Ord>> Iterator for IntoIterSorted<T> {
    type Item = T::Item;

    #[inline]
    fn next(&mut self) -> Option<T::Item> {
        self.inner.pop()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let exact = self.inner.len();
        (exact, Some(exact))
    }
}

impl<T: Vec<Item:Ord>> ExactSizeIterator for IntoIterSorted<T> {}

impl<T: Vec<Item:Ord>> FusedIterator for IntoIterSorted<T> {}

pub struct DrainSorted<'a, T: Vec<Item:Ord>> {
    inner: &'a mut BinaryHeap<T>,
}

impl<'a, T: Vec<Item:Ord + fmt::Debug>> fmt::Debug for DrainSorted<'a, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("DrainSorted").field("inner", &self.inner).finish()
    }
}

impl<'a, T: Vec<Item:Ord>> Drop for DrainSorted<'a, T> {
    /// Removes heap elements in heap order.
    fn drop(&mut self) {
        struct DropGuard<'r, 'a, T: Vec<Item:Ord>>(&'r mut DrainSorted<'a, T>);

        impl<'r, 'a, T: Vec<Item:Ord>> Drop for DropGuard<'r, 'a, T> {
            fn drop(&mut self) {
                while self.0.inner.pop().is_some() {}
            }
        }

        while let Some(item) = self.inner.pop() {
            let guard = DropGuard(self);
            drop(item);
            mem::forget(guard);
        }
    }
}

impl<T: Vec<Item:Ord>> Iterator for DrainSorted<'_, T> {
    type Item = T::Item;

    #[inline]
    fn next(&mut self) -> Option<T::Item> {
        self.inner.pop()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let exact = self.inner.len();
        (exact, Some(exact))
    }
}

impl<T: Vec<Item:Ord>> ExactSizeIterator for DrainSorted<'_, T> {}

impl<T: Vec<Item:Ord>> FusedIterator for DrainSorted<'_, T> {}

// impl<T: Vec<Item:Ord>> From<T> for BinaryHeap<T> {
//     /// Converts a `V` into a `BinaryHeap<T>`.
//     ///
//     /// This conversion happens in-placend has *O*(*n*) time complexity.
//     fn from(vec: T) -> BinaryHeap<T> {
//         let mut heap = BinaryHeap { data: vec };
//         heap.rebuild();
//         heap
//     }
// }

// impl<T: Vec<Item:Ord>, const N: usize> From<[T; N]> for BinaryHeap<T> {
//     /// ```
//     /// use std::collections::BinaryHeap;
//     ///
//     /// let mut h1 = BinaryHeap::from([1, 4, 2, 3]);
//     /// let mut h2: BinaryHeap<_> = [1, 4, 2, 3].into();
//     /// while let Some((a, b)) = h1.pop().zip(h2.pop()) {
//     ///     assert_eq!(a, b);
//     /// }
//     /// ```
//     fn from(arr: [T; N]) -> Self {
//         Self::from_iter(arr)
//     }
// }

impl<T: Vec<Item: Ord>> FromIterator<T> for BinaryHeap<T> {
    fn from_iter<I: IntoIterator<Item = T>>(iter: I) -> BinaryHeap<T> {
        BinaryHeap::from(iter.into_iter().collect())
    }
}

impl<T: SliceOwner> IntoIterator for BinaryHeap<T> {
    type Item = T::Item;
    type IntoIter = T::IntoIter;

    /// Creates a consuming iterator, that is, one that moves each value out of
    /// the binary heap in arbitrary order. The binary heap cannot be used
    /// after calling this.
    ///
    /// # Examples
    ///
    /// Basic usage:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from([1, 2, 3, 4]);
    ///
    /// // Print 1, 2, 3, 4 in arbitrary order
    /// for x in heap.into_iter() {
    ///     // x has type i32, not &i32
    ///     println!("{x}");
    /// }
    /// ```
    fn into_iter(self) -> T::IntoIter {
        self.data.into_iter()
    }
}

impl<'a, T: SliceOwner> IntoIterator for &'a BinaryHeap<T> {
    type Item = &'a T::Item;

    type IntoIter = core::slice::Iter<'a, T::Item>;

    fn into_iter(self) -> Self::IntoIter {
        self.data.as_ref().iter()
    }
}

impl<T: Vec<Item: Ord>> Extend<T::Item> for BinaryHeap<T> {
    #[inline]
    fn extend<I: IntoIterator<Item = T::Item>>(&mut self, iter: I) {
        let guard = RebuildOnDrop {
            rebuild_from: self.len(),
            heap: self,
        };
        guard.heap.data.extend(iter);
    }
}